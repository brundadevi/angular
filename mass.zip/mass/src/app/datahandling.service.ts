import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Deto } from './deto';
import { Observable, of } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DatahandlingService {

  constructor(private http: HttpClient) { }

  private detoesUrl = 'api/detoes';
  

    httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': 'my-auth-token'
    })
  };
  getDetoes (): Observable<Deto[]> {
    return this.http.get<Deto[]>(this.detoesUrl)
      .pipe(
        //tap(_ => this.log('fetched heroes')),
        catchError(this.handleError('getDetoes', []))
      );
  }
  addDeto (deto: Deto) {
     return this.http.post<Deto>(this.detoesUrl, deto);
     // .pipe(
       // catchError(this.handleError('addDeto', deto))
      //);
  }
  // addDeto (deto:Deto): Observable<Deto> {
  //   return this.http.post<Deto>(this.detoesUrl, deto, httpOptions).pipe(
  //    // tap((hero: Hero) => this.log(`added hero w/ id=${hero.id}`)),
  //     catchError(this.handleError<Deto>('addDeto'))
  //   );

  // }

  // addDetoes (deto:Deto): Observable<Deto> {
  //   return this.http.post<Deto>(this.detoesUrl, deto, httpOptions)
  //     .pipe(
  //       //tap(_ => this.log('fetched heroes')),
  //       catchError(this.handleError<Deto>('addDetoes'))
  //     );
  // }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
   
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
   
      // TODO: better job of transforming error for user consumption
     
   
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
