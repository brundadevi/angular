import { Injectable } from '@angular/core';
import { Deto } from './deto';
import { InMemoryDbService } from 'angular-in-memory-web-api';
@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService {

  constructor() { }

  createDb() {
    const detoes = [
      { id: 1, jobcode: 'Mr. Nice',date:'hello',batchno:'11',random:'random' },
      { id: 2, jobcode: 'Narco',date:'hello2',batchno:'12',random:'random2' },
      { id: 3, jobcode: 'Bombasto',date:'hello',batchno:'123',random:'random3' }
    ];
    return {detoes};
  }

  // Overrides the genId method to ensure that a hero always has an id.
  // If the heroes array is empty,
  // the method below returns the initial number (11).
  // if the heroes array is not empty, the method below returns the highest
  // hero id + 1.
  genId(detoes: Deto[]): number {
    return detoes.length > 0 ? Math.max(...detoes.map(deto => deto.id)) + 1 : 1;
  }
}





