import { Component, OnInit } from '@angular/core';
import { Deto } from '../deto';
import { DatahandlingService } from '../datahandling.service';
@Component({
  selector: 'app-adding',
  templateUrl: './adding.component.html',
  styleUrls: ['./adding.component.css']
})
export class AddingComponent implements OnInit {
  //det : Deto;
 usermodel : Deto;


bob1: Deto = {
  
  id:9,
  jobcode:'dfdfd' ,
  date:'fdfd',
  batchno:3,
  random:'fdfd',
};
OnSubmit()
{
  console.log(this.usermodel);
}

  constructor(private ds:DatahandlingService) { }
detoes: Deto[];
  ngOnInit() {
    
    this.addDetoes();
    this.getDetoes();
    
  }
  getDetoes(): void {
    this.ds.getDetoes()
    .subscribe(detoes => this.detoes = detoes);
  }


   bob: Deto = {
  
    id: 35,
    jobcode:'dfdfd' ,
    date:'fdfd',
    batchno:3,
    random:'fdfd',
};

 
 


  addDetoes() :any{
    this.ds.addDeto(this.bob)
    .subscribe(detoes => console.log('Success',detoes))
  }

// //b='dfd';



//   add(name: string): void {
//     name = name.trim();
//     if (!name) { return; }
//    // this.ds.addDeto({this.a:number, name:string,  this.b:string, this.c:number, this.d:string } as Deto)
//           .subscribe(deto => {
//         this.detoes.push(deto);
//       });
 // }--------------------------------------------------------------------
}
